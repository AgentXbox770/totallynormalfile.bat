@echo off

:: ---- GUI WARNING ----
if "%~1"=="" (
mshta "javascript:var sh=new ActiveXObject('WScript.Shell');var r=sh.Popup('run at your own risk?',0,'totallynormalfile.bat by agentxbox',48+4);if(r==6){sh.Run('\"%~f0\" go',0);}close();"
exit /b
)

title UltMa

REM --- Change wallpaper ---
set "wallpaper=%~dp0wallpaper.png"
reg add "HKCU\Control Panel\Desktop" /v Wallpaper /t REG_SZ /d "%wallpaper%" /f >nul 2>&1
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters

REM --- Open random programs ---
start notepad
start calc
start mspaint
start explorer
start mspaint
start chrome
start regedit
start explorer

REM --- Open websites ---
start https://google.com
start https://youtube.com
start https://wikipedia.org
start https://bing.com
start https://reddit.com

REM --- Open 5 CMDs running dir /s ---
for /L %%i in (1,1,5) do (
start "" cmd /k dir /s
)

REM --- Open 5 CMDs with red text + parrot.live ---
for /L %%i in (1,1,5) do (
start "" cmd /k "color 4 & curl -L parrot.live"
)