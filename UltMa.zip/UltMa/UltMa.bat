@echo off
title UltMa

REM --- Open random programs ---
start notepad
start calc
start mspaint
start explorer
start mspaint
REM Chrome may need full path if not in PATH
REM start "" "C:\Program Files\Google\Chrome\Application\chrome.exe"
start regedit
start explorer

REM --- Open websites ---
start https://google.com
start https://youtube.com
start https://wikipedia.org
start https://bing.com
start https://reddit.com

REM --- Open 5 CMDs running dir /s ---
for /L %%i in (1,1,5) do (
    start "" cmd /k dir /s
)

REM --- Open 5 CMDs with red text + parrot.live ---
for /L %%i in (1,1,5) do (
    start "" cmd /k "color 4 & curl -L parrot.live"
)